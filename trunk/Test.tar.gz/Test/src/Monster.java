import java.awt.image.BufferedImage;

import com.golden.gamedev.object.Sprite;


@SuppressWarnings("serial")
public class Monster extends Sprite {
	

	public Monster(BufferedImage i) {
		setImage(i);
	}
	
	public void update(long t) {
		
	}
}
